class Prg3
{
public static void main(String args[])
{
int a=5;
int b;
System.out.println("a is :"+ a); //5
b=a++;
System.out.println("a is :"+ a); //6
System.out.println("b is :"+ b); //5
b=a++;
System.out.println("a is :" +a);//7
System.out.println("b is :" +b);//7
b=a--;
System.out.println("a is :" +a);//6
System.out.println("b is :" +b);//7
b=--a;
System.out.println("a is :" +a);//5
System.out.println("b is :" +b);//5
}
}