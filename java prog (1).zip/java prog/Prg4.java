//Reverse a number without using any for loop and any predefined function
//Note: Should use only one variable. May use N no of statements

class Prg4
{
public static void main(String args[])
{
int a=12345;
System.out.print(a%10); //5
a=a/10;
System.out.print(a%10);//4
a=a/10;
System.out.print(a%10);//3
a=a/10;
System.out.print(a%10);//2
a=a/10;
System.out.print(a%10);//1
}
}

