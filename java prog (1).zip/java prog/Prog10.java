import java.util.Scanner;
class main
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("enter a :");
int a=sc.nextInt();

System.out.print("enter b :");
int b=sc.nextInt();

System.out.println(a>b?"a is big":"b is big");//Optimized code 

}
}
//?True part: false part