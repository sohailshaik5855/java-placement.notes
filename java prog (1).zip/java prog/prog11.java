			
int a=sc.nextInt();

System.out.print("enter b :");
int b=sc.nextInt();

System.out.print("enter c :");
int c=sc.nextInt();

System.out.println((a>b)?((a>c)?"a is big":"c is big"):((b>c)?"b is big":"c is big"));
}
}