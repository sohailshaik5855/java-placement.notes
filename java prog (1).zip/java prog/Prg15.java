import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int no = sc.nextInt();
        System.out.print("Enter the no:");
        for(int i=1;i<=no;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j+"");
            }
        }
        System.out.println(i+"");
    }
}
----------------------------------------------------------------
import java.util.Scanner;
class Main {
    public static void main(String[] args) 
{
int a=60;
int b=13;
int c;
c=a&b;
System.out.println("c is :"+c);
c=a/b;
System.out.println("c is :"+c);
c=a^b;
System.out.println("c is :"+c);
}
}
---------------------------------------------------------------------
class main{
public static void main(String args[]){
int num=1234;
char ch[]=String.valueOf(num).toCharArray();
for (Char c:ch)
{
System.outy..println(c ="-KLU");
}
}
}
--------------------------------------------------------------------------
