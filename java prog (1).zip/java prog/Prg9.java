import java.util.Scanner;
class main
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a Character : ");
char ch = sc.next().charAt(0); // to get input a single character
int as= ch;
System.out.println("Character is :" +ch +"-Ascii:"+as);
}
}

// sc.next();get input as string format.even its a single character