import java.util.Scanner;
class main{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter No:");
int no = sc.nextInt();
for(int i=0;i<=no;i++)
{
System.out.println(i+"");
}}}
----------------------------------------------------------------------------------------------------
import java.util.Scanner;
class main{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter No:");
int no = sc.nextInt();
for(int i=no;i>=1;i--)
{
System.out.println(i+"");
}}}
------------------------------------------------------------------
import java.util.Scanner;
class main{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter No:");
int no = sc.nextInt();
for(int i=0;i<=no;i=i+3)
{
System.out.println(i+"");
}}}
-----------------------------------------------------------------------

import java.util.Scanner;
class main{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter No:");
int no = sc.nextInt();
int i,j;
for(i=1,j=1;i<=no && j<=no;i=i+2,j=j+3)
{
System.out.println("i is :" +i +" -j is : " +j);
}
}
}
------------------------------------------------------------------------------------
Ex
Test case:
input: No -10
table -5
ouput :
1*5=5
2*5=10
.
.
.
10*5=50


import java.util.Scanner;
class main{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter No:");
int no = sc.nextInt();
int i;
for(i=no;i>=1;i++)
{
    int result =i*5;
System.out.println( i+"*5="+result);
}
}
}
---------------------------------------------------------------------------------
import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int no = sc.nextInt();
        for(int i=1;i<=no;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j+"");
            }
            System.out.println(i+"");
        }
        
    }
}
----------------------------------------------------------------------------------------

