import java.util.Scanner;
class main
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("enter a :");
char c=sc.next().charAt(0);
switch(c)
{
case'a':
case'e':
case'i':
case'o':
case'u':
case'A':
case'E':
case'I':
case'O':
case'U':
System.out.println("vowel:" +c);
break;
default:
System.lout.println("Not Vowel:" +c);
break;
}
}
}

