import java.util.Scanner;
class main
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Enter No : ");
int no= sc.nextInt();

if (no>0 && no <10)
   System.out.println("Single Digit :" +no);
else if (no>=10 && no<100)
   System.out.println("Double Digit :" +no);
else if (no>=100 && no<1000)
   System.out.println("Three Digit :" + no);
else 
    System.out.println("fourth Digit :" +no);
}
}


